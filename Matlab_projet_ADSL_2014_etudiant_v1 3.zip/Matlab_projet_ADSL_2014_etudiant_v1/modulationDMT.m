function x=modulationDMT(suite_symboles_in,nombre_canaux,prefixe_cyclique)

% suite_symboles_in suite des symboles complexes � transmettre
% nombre_canaux nombre de canaux utilis�s
% prefixe_cyclique la longueur du CP
 
 
% a compl�ter...
